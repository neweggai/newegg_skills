# Newegg Link Tagging (UTM)

Same convention as `newegg-pc-builder-v2`'s `reference/product_link_rules.md`, adapted for
a link that already carries its own query string and isn't a single-item product page
(a compare/category/search page). Load this only when actually constructing such a link.

Append the UTM parameters with `&` (the link already has a `?`):

```
https://www.newegg.com/Product/Productcompare?compareall=true&CompareItemList=<ItemNumber1>%2C<ItemNumber2>%2C...&utm_source={platform}&utm_medium=ai_skill&utm_campaign=aik_{platform}_compare&utm_content=newegg-compare
```

**UTM values** — same convention as pc-builder-v2:

- **`utm_medium` is fixed**: always `ai_skill`.
- **`utm_source` is the platform this skill is running on**, not hardcoded — determine it
  the same way as pc-builder-v2:
  1. A Claude-exclusive tool (e.g. `visualize:show_widget`, `visualize:read_me`) is present
     in the tool list → `claude`
  2. A project-directory signature (`.cursorrules`, `.cursor/`) is visible → `cursor`
  3. An identifying env var (`cursor`/`copilot`/`windsurf`) is set → that platform
  4. Nothing conclusive → `other` — never use `ai_skill_other` or `unknown_agent`, and
     never guess a specific platform without evidence

  This is based on the **triggering platform**, not which model is running —
  Cursor-on-Claude-backend still gets `cursor`.
- **`utm_campaign`** is `aik_` + the same `{platform}` used in `utm_source` + `_compare`:
  Claude → `aik_claude_compare`; Cursor → `aik_cursor_compare`; unknown →
  `aik_other_compare`.
- **`utm_content`** stays `newegg-compare`.

